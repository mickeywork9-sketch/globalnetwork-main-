import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { Toaster } from 'sonner';
import Index from './pages/Index';
import Candidates from './pages/Candidates';
import Employers from './pages/Employers';
import About from './pages/About';
import Contact from './pages/Contact';
import EmployerAuth from './pages/EmployerAuth';
import EmployerSubscription from './pages/EmployerSubscription';
import NewEmployerDashboard from './pages/NewEmployerDashboard';
import ApplicantManagement from './pages/ApplicantManagement';
import JobSeekerDashboard from './pages/JobSeekerDashboard';
import JobSeekerUpgrade from './pages/JobSeekerUpgrade';
import ProtectedRoute from './components/ProtectedRoute';

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="App">
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/candidates" element={<JobSeekerDashboard />} />
            <Route path="/job-seeker-dashboard" element={<JobSeekerDashboard />} />
            <Route path="/job-seeker-upgrade" element={<JobSeekerUpgrade />} />
            <Route path="/employers" element={<Employers />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/employer-auth" element={<EmployerAuth />} />
            <Route path="/employer-subscription" element={<EmployerSubscription />} />
            <Route 
              path="/employer-dashboard" 
              element={
                <ProtectedRoute>
                  <NewEmployerDashboard />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/applicant-management" 
              element={
                <ProtectedRoute>
                  <ApplicantManagement />
                </ProtectedRoute>
              } 
            />
          </Routes>
          <Toaster position="top-right" />
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;