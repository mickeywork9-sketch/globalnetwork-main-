import { Toaster } from '@/components/ui/sonner';
import { TooltipProvider } from '@/components/ui/tooltip';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '@/contexts/AuthContext';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import Index from './pages/Index';
import Candidates from './pages/Candidates';
import Employers from './pages/Employers';
import EmployerAuth from './pages/EmployerAuth';
import EmployerSubscription from './pages/EmployerSubscription';
import EmployerDashboard from './pages/EmployerDashboard';
import NewEmployerDashboard from './pages/NewEmployerDashboard';
import About from './pages/About';
import Contact from './pages/Contact';
import NotFound from './pages/NotFound';

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <AuthProvider>
        <Toaster />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/candidates" element={<Candidates />} />
            <Route path="/employers" element={<Employers />} />
            <Route path="/employer-auth" element={<EmployerAuth />} />
            <Route 
              path="/employer-subscription" 
              element={
                <ProtectedRoute>
                  <EmployerSubscription />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/employer-dashboard" 
              element={
                <ProtectedRoute requireSubscription>
                  <NewEmployerDashboard />
                </ProtectedRoute>
              } 
            />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;