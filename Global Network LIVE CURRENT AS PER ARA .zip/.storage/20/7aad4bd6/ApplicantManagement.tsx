import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { ArrowLeft, Search, Filter, Eye, Download, MessageSquare, CheckCircle, XCircle, Clock, User } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface Applicant {
  id: string;
  name: string;
  email: string;
  phone: string;
  jobId: string;
  jobTitle: string;
  appliedDate: string;
  status: 'pending' | 'reviewing' | 'interviewed' | 'hired' | 'rejected';
  experience: string;
  skills: string[];
  location: string;
  salary: string;
  resumeUrl: string;
  coverLetter: string;
  profileImage?: string;
  education: string;
  portfolio?: string;
}

const ApplicantManagement: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [applicants, setApplicants] = useState<Applicant[]>([]);
  const [filteredApplicants, setFilteredApplicants] = useState<Applicant[]>([]);
  const [selectedApplicant, setSelectedApplicant] = useState<Applicant | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [jobFilter, setJobFilter] = useState('all');
  const [showFilters, setShowFilters] = useState(false);

  // Mock data for demonstration
  useEffect(() => {
    const mockApplicants: Applicant[] = [
      {
        id: '1',
        name: 'Sarah Johnson',
        email: 'sarah.johnson@email.com',
        phone: '+1 (555) 123-4567',
        jobId: 'job1',
        jobTitle: 'Senior Frontend Developer',
        appliedDate: '2024-01-15',
        status: 'reviewing',
        experience: '5+ years',
        skills: ['React', 'TypeScript', 'Node.js', 'GraphQL'],
        location: 'San Francisco, CA',
        salary: '$120,000 - $140,000',
        resumeUrl: '/resumes/sarah-johnson.pdf',
        coverLetter: 'I am excited to apply for the Senior Frontend Developer position...',
        education: 'BS Computer Science - Stanford University',
        portfolio: 'https://sarahjohnson.dev'
      },
      {
        id: '2',
        name: 'Michael Chen',
        email: 'michael.chen@email.com',
        phone: '+1 (555) 987-6543',
        jobId: 'job1',
        jobTitle: 'Senior Frontend Developer',
        appliedDate: '2024-01-14',
        status: 'interviewed',
        experience: '7+ years',
        skills: ['React', 'Vue.js', 'Python', 'AWS'],
        location: 'Seattle, WA',
        salary: '$130,000 - $150,000',
        resumeUrl: '/resumes/michael-chen.pdf',
        coverLetter: 'With over 7 years of experience in frontend development...',
        education: 'MS Software Engineering - University of Washington'
      },
      {
        id: '3',
        name: 'Emily Rodriguez',
        email: 'emily.rodriguez@email.com',
        phone: '+1 (555) 456-7890',
        jobId: 'job2',
        jobTitle: 'UX/UI Designer',
        appliedDate: '2024-01-13',
        status: 'pending',
        experience: '4+ years',
        skills: ['Figma', 'Adobe Creative Suite', 'Prototyping', 'User Research'],
        location: 'Austin, TX',
        salary: '$85,000 - $100,000',
        resumeUrl: '/resumes/emily-rodriguez.pdf',
        coverLetter: 'I am passionate about creating user-centered designs...',
        education: 'BFA Graphic Design - Art Institute of Austin',
        portfolio: 'https://emilyrodriguez.design'
      },
      {
        id: '4',
        name: 'David Kim',
        email: 'david.kim@email.com',
        phone: '+1 (555) 321-0987',
        jobId: 'job3',
        jobTitle: 'Backend Developer',
        appliedDate: '2024-01-12',
        status: 'hired',
        experience: '6+ years',
        skills: ['Java', 'Spring Boot', 'PostgreSQL', 'Docker'],
        location: 'New York, NY',
        salary: '$115,000 - $135,000',
        resumeUrl: '/resumes/david-kim.pdf',
        coverLetter: 'I have extensive experience in backend development...',
        education: 'BS Computer Engineering - NYU'
      },
      {
        id: '5',
        name: 'Lisa Thompson',
        email: 'lisa.thompson@email.com',
        phone: '+1 (555) 654-3210',
        jobId: 'job1',
        jobTitle: 'Senior Frontend Developer',
        appliedDate: '2024-01-11',
        status: 'rejected',
        experience: '3+ years',
        skills: ['React', 'JavaScript', 'CSS', 'HTML'],
        location: 'Denver, CO',
        salary: '$90,000 - $110,000',
        resumeUrl: '/resumes/lisa-thompson.pdf',
        coverLetter: 'I am eager to contribute to your frontend team...',
        education: 'BS Information Technology - Colorado State University'
      }
    ];

    setApplicants(mockApplicants);
    setFilteredApplicants(mockApplicants);
  }, []);

  // Filter applicants based on search and filters
  useEffect(() => {
    let filtered = applicants;

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(applicant =>
        applicant.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        applicant.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        applicant.jobTitle.toLowerCase().includes(searchTerm.toLowerCase()) ||
        applicant.skills.some(skill => skill.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    // Status filter
    if (statusFilter !== 'all') {
      filtered = filtered.filter(applicant => applicant.status === statusFilter);
    }

    // Job filter
    if (jobFilter !== 'all') {
      filtered = filtered.filter(applicant => applicant.jobId === jobFilter);
    }

    setFilteredApplicants(filtered);
  }, [applicants, searchTerm, statusFilter, jobFilter]);

  const updateApplicantStatus = (applicantId: string, newStatus: Applicant['status']) => {
    setApplicants(prev =>
      prev.map(applicant =>
        applicant.id === applicantId ? { ...applicant, status: newStatus } : applicant
      )
    );
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'reviewing': return 'bg-blue-100 text-blue-800';
      case 'interviewed': return 'bg-purple-100 text-purple-800';
      case 'hired': return 'bg-green-100 text-green-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending': return <Clock className="w-4 h-4" />;
      case 'reviewing': return <Eye className="w-4 h-4" />;
      case 'interviewed': return <MessageSquare className="w-4 h-4" />;
      case 'hired': return <CheckCircle className="w-4 h-4" />;
      case 'rejected': return <XCircle className="w-4 h-4" />;
      default: return <User className="w-4 h-4" />;
    }
  };

  const uniqueJobs = [...new Set(applicants.map(a => ({ id: a.jobId, title: a.jobTitle })))];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <button
                onClick={() => navigate('/employer-dashboard')}
                className="flex items-center text-gray-600 hover:text-gray-900 mr-4"
              >
                <ArrowLeft className="w-5 h-5 mr-2" />
                Back to Dashboard
              </button>
              <h1 className="text-2xl font-bold text-gray-900">Applicant Management</h1>
            </div>
            <div className="text-sm text-gray-500">
              {filteredApplicants.length} of {applicants.length} applicants
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search and Filters */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            {/* Search */}
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search applicants..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            {/* Filters */}
            <div className="flex items-center gap-4">
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                <Filter className="w-4 h-4 mr-2" />
                Filters
              </button>
            </div>
          </div>

          {/* Filter Options */}
          {showFilters && (
            <div className="mt-4 pt-4 border-t border-gray-200">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Status</label>
                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="all">All Statuses</option>
                    <option value="pending">Pending</option>
                    <option value="reviewing">Reviewing</option>
                    <option value="interviewed">Interviewed</option>
                    <option value="hired">Hired</option>
                    <option value="rejected">Rejected</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Job Position</label>
                  <select
                    value={jobFilter}
                    onChange={(e) => setJobFilter(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="all">All Positions</option>
                    {uniqueJobs.map(job => (
                      <option key={job.id} value={job.id}>{job.title}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Applicants List */}
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          {filteredApplicants.length === 0 ? (
            <div className="text-center py-12">
              <User className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No applicants found</h3>
              <p className="text-gray-500">
                {searchTerm || statusFilter !== 'all' || jobFilter !== 'all'
                  ? 'Try adjusting your search or filters'
                  : 'No applications have been received yet'}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Applicant
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Position
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Applied Date
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Experience
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredApplicants.map((applicant) => (
                    <tr key={applicant.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="flex-shrink-0 h-10 w-10">
                            <div className="h-10 w-10 rounded-full bg-blue-500 flex items-center justify-center">
                              <span className="text-white font-medium">
                                {applicant.name.split(' ').map(n => n[0]).join('')}
                              </span>
                            </div>
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">{applicant.name}</div>
                            <div className="text-sm text-gray-500">{applicant.email}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{applicant.jobTitle}</div>
                        <div className="text-sm text-gray-500">{applicant.location}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {new Date(applicant.appliedDate).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(applicant.status)}`}>
                          {getStatusIcon(applicant.status)}
                          <span className="ml-1 capitalize">{applicant.status}</span>
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {applicant.experience}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <button
                          onClick={() => setSelectedApplicant(applicant)}
                          className="text-blue-600 hover:text-blue-900 mr-4"
                        >
                          View Details
                        </button>
                        <a
                          href={applicant.resumeUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-green-600 hover:text-green-900"
                        >
                          <Download className="w-4 h-4 inline" />
                        </a>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Applicant Details Modal */}
      {selectedApplicant && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              {/* Modal Header */}
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-900">Applicant Details</h2>
                <button
                  onClick={() => setSelectedApplicant(null)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <XCircle className="w-6 h-6" />
                </button>
              </div>

              {/* Applicant Info */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Left Column */}
                <div>
                  <div className="bg-gray-50 rounded-lg p-6 mb-6">
                    <div className="flex items-center mb-4">
                      <div className="h-16 w-16 rounded-full bg-blue-500 flex items-center justify-center mr-4">
                        <span className="text-white text-xl font-medium">
                          {selectedApplicant.name.split(' ').map(n => n[0]).join('')}
                        </span>
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold text-gray-900">{selectedApplicant.name}</h3>
                        <p className="text-gray-600">{selectedApplicant.email}</p>
                        <p className="text-gray-600">{selectedApplicant.phone}</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="font-medium text-gray-700">Location:</span>
                        <p className="text-gray-600">{selectedApplicant.location}</p>
                      </div>
                      <div>
                        <span className="font-medium text-gray-700">Experience:</span>
                        <p className="text-gray-600">{selectedApplicant.experience}</p>
                      </div>
                      <div>
                        <span className="font-medium text-gray-700">Salary Expectation:</span>
                        <p className="text-gray-600">{selectedApplicant.salary}</p>
                      </div>
                      <div>
                        <span className="font-medium text-gray-700">Applied Date:</span>
                        <p className="text-gray-600">{new Date(selectedApplicant.appliedDate).toLocaleDateString()}</p>
                      </div>
                    </div>
                  </div>

                  {/* Skills */}
                  <div className="mb-6">
                    <h4 className="text-lg font-semibold text-gray-900 mb-3">Skills</h4>
                    <div className="flex flex-wrap gap-2">
                      {selectedApplicant.skills.map((skill, index) => (
                        <span
                          key={index}
                          className="px-3 py-1 bg-blue-100 text-blue-800 text-sm rounded-full"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Education */}
                  <div className="mb-6">
                    <h4 className="text-lg font-semibold text-gray-900 mb-3">Education</h4>
                    <p className="text-gray-600">{selectedApplicant.education}</p>
                  </div>

                  {/* Portfolio */}
                  {selectedApplicant.portfolio && (
                    <div className="mb-6">
                      <h4 className="text-lg font-semibold text-gray-900 mb-3">Portfolio</h4>
                      <a
                        href={selectedApplicant.portfolio}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:text-blue-800 underline"
                      >
                        {selectedApplicant.portfolio}
                      </a>
                    </div>
                  )}
                </div>

                {/* Right Column */}
                <div>
                  {/* Job Applied For */}
                  <div className="bg-gray-50 rounded-lg p-6 mb-6">
                    <h4 className="text-lg font-semibold text-gray-900 mb-3">Applied Position</h4>
                    <p className="text-gray-900 font-medium">{selectedApplicant.jobTitle}</p>
                  </div>

                  {/* Status Management */}
                  <div className="mb-6">
                    <h4 className="text-lg font-semibold text-gray-900 mb-3">Application Status</h4>
                    <div className="space-y-2">
                      {['pending', 'reviewing', 'interviewed', 'hired', 'rejected'].map((status) => (
                        <button
                          key={status}
                          onClick={() => updateApplicantStatus(selectedApplicant.id, status as Applicant['status'])}
                          className={`w-full text-left px-4 py-2 rounded-lg border transition-colors ${
                            selectedApplicant.status === status
                              ? 'border-blue-500 bg-blue-50 text-blue-700'
                              : 'border-gray-300 hover:bg-gray-50'
                          }`}
                        >
                          <div className="flex items-center">
                            {getStatusIcon(status)}
                            <span className="ml-2 capitalize">{status}</span>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Cover Letter */}
                  <div className="mb-6">
                    <h4 className="text-lg font-semibold text-gray-900 mb-3">Cover Letter</h4>
                    <div className="bg-gray-50 rounded-lg p-4 max-h-48 overflow-y-auto">
                      <p className="text-gray-700 text-sm leading-relaxed">{selectedApplicant.coverLetter}</p>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-3">
                    <a
                      href={selectedApplicant.resumeUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-center"
                    >
                      <Download className="w-4 h-4 inline mr-2" />
                      Download Resume
                    </a>
                    <button className="flex-1 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors">
                      <MessageSquare className="w-4 h-4 inline mr-2" />
                      Send Message
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ApplicantManagement;