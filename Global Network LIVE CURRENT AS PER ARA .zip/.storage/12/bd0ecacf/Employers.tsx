import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import { Users, Zap, DollarSign, Send, ArrowRight, Building2, Crown, Shield } from 'lucide-react';

const currencyOptions = [
  { code: 'USD', symbol: '$', country: 'United States', flag: '🇺🇸' },
  { code: 'EUR', symbol: '€', country: 'European Union', flag: '🇪🇺' },
  { code: 'GBP', symbol: '£', country: 'United Kingdom', flag: '🇬🇧' },
  { code: 'CAD', symbol: 'C$', country: 'Canada', flag: '🇨🇦' },
  { code: 'AUD', symbol: 'A$', country: 'Australia', flag: '🇦🇺' },
  { code: 'JPY', symbol: '¥', country: 'Japan', flag: '🇯🇵' },
  { code: 'CHF', symbol: 'CHF', country: 'Switzerland', flag: '🇨🇭' },
  { code: 'SGD', symbol: 'S$', country: 'Singapore', flag: '🇸🇬' },
  { code: 'HKD', symbol: 'HK$', country: 'Hong Kong', flag: '🇭🇰' },
  { code: 'INR', symbol: '₹', country: 'India', flag: '🇮🇳' },
  { code: 'CNY', symbol: '¥', country: 'China', flag: '🇨🇳' },
  { code: 'AED', symbol: 'AED', country: 'UAE', flag: '🇦🇪' },
  { code: 'ZAR', symbol: 'R', country: 'South Africa', flag: '🇿🇦' },
  { code: 'BRL', symbol: 'R$', country: 'Brazil', flag: '🇧🇷' },
  { code: 'MXN', symbol: 'MX$', country: 'Mexico', flag: '🇲🇽' },
];

const getSalaryRanges = (currency: string, symbol: string) => {
  const ranges = {
    USD: [
      { value: '30k-50k', label: `${symbol}30,000 - ${symbol}50,000` },
      { value: '50k-75k', label: `${symbol}50,000 - ${symbol}75,000` },
      { value: '75k-100k', label: `${symbol}75,000 - ${symbol}100,000` },
      { value: '100k-150k', label: `${symbol}100,000 - ${symbol}150,000` },
      { value: '150k-200k', label: `${symbol}150,000 - ${symbol}200,000` },
      { value: '200k+', label: `${symbol}200,000+` },
    ],
    EUR: [
      { value: '25k-40k', label: `${symbol}25,000 - ${symbol}40,000` },
      { value: '40k-60k', label: `${symbol}40,000 - ${symbol}60,000` },
      { value: '60k-80k', label: `${symbol}60,000 - ${symbol}80,000` },
      { value: '80k-120k', label: `${symbol}80,000 - ${symbol}120,000` },
      { value: '120k-160k', label: `${symbol}120,000 - ${symbol}160,000` },
      { value: '160k+', label: `${symbol}160,000+` },
    ],
    GBP: [
      { value: '20k-35k', label: `${symbol}20,000 - ${symbol}35,000` },
      { value: '35k-50k', label: `${symbol}35,000 - ${symbol}50,000` },
      { value: '50k-70k', label: `${symbol}50,000 - ${symbol}70,000` },
      { value: '70k-100k', label: `${symbol}70,000 - ${symbol}100,000` },
      { value: '100k-140k', label: `${symbol}100,000 - ${symbol}140,000` },
      { value: '140k+', label: `${symbol}140,000+` },
    ],
    CAD: [
      { value: '40k-60k', label: `${symbol}40,000 - ${symbol}60,000` },
      { value: '60k-80k', label: `${symbol}60,000 - ${symbol}80,000` },
      { value: '80k-110k', label: `${symbol}80,000 - ${symbol}110,000` },
      { value: '110k-150k', label: `${symbol}110,000 - ${symbol}150,000` },
      { value: '150k-200k', label: `${symbol}150,000 - ${symbol}200,000` },
      { value: '200k+', label: `${symbol}200,000+` },
    ],
    AUD: [
      { value: '45k-65k', label: `${symbol}45,000 - ${symbol}65,000` },
      { value: '65k-85k', label: `${symbol}65,000 - ${symbol}85,000` },
      { value: '85k-120k', label: `${symbol}85,000 - ${symbol}120,000` },
      { value: '120k-160k', label: `${symbol}120,000 - ${symbol}160,000` },
      { value: '160k-220k', label: `${symbol}160,000 - ${symbol}220,000` },
      { value: '220k+', label: `${symbol}220,000+` },
    ],
    JPY: [
      { value: '3M-5M', label: `${symbol}3,000,000 - ${symbol}5,000,000` },
      { value: '5M-7M', label: `${symbol}5,000,000 - ${symbol}7,000,000` },
      { value: '7M-10M', label: `${symbol}7,000,000 - ${symbol}10,000,000` },
      { value: '10M-15M', label: `${symbol}10,000,000 - ${symbol}15,000,000` },
      { value: '15M-20M', label: `${symbol}15,000,000 - ${symbol}20,000,000` },
      { value: '20M+', label: `${symbol}20,000,000+` },
    ],
    INR: [
      { value: '5L-10L', label: `${symbol}5,00,000 - ${symbol}10,00,000` },
      { value: '10L-15L', label: `${symbol}10,00,000 - ${symbol}15,00,000` },
      { value: '15L-25L', label: `${symbol}15,00,000 - ${symbol}25,00,000` },
      { value: '25L-40L', label: `${symbol}25,00,000 - ${symbol}40,00,000` },
      { value: '40L-60L', label: `${symbol}40,00,000 - ${symbol}60,00,000` },
      { value: '60L+', label: `${symbol}60,00,000+` },
    ],
  };

  return ranges[currency as keyof typeof ranges] || ranges.USD;
};

export default function Employers() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    companyName: '',
    contactPerson: '',
    email: '',
    jobTitle: '',
    currency: 'USD',
    salaryRange: '',
    jobDescription: '',
    urgency: ''
  });

  const selectedCurrency = currencyOptions.find(c => c.code === formData.currency);
  const salaryRanges = getSalaryRanges(formData.currency, selectedCurrency?.symbol || '$');

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ 
      ...prev, 
      [field]: value,
      // Reset salary range when currency changes
      ...(field === 'currency' ? { salaryRange: '' } : {})
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic validation
    if (!formData.companyName || !formData.contactPerson || !formData.email || 
        !formData.jobTitle || !formData.currency || !formData.salaryRange || 
        !formData.jobDescription || !formData.urgency) {
      toast.error('Please fill in all fields');
      return;
    }

    // Simulate form submission
    toast.success('Request submitted successfully! We\'ll send you candidate profiles soon.');
    
    // Reset form
    setFormData({
      companyName: '',
      contactPerson: '',
      email: '',
      jobTitle: '',
      currency: 'USD',
      salaryRange: '',
      jobDescription: '',
      urgency: ''
    });
  };

  const handleAccessPortal = () => {
    navigate('/employer-auth');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-white">
      {/* Hero Section */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Hire Top Talent Fast
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            We simplify recruitment. Share your job requirements and receive a shortlist 
            of vetted candidates quickly and efficiently.
          </p>
          
          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button 
              onClick={handleAccessPortal}
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 text-lg"
              size="lg"
            >
              <Building2 className="h-5 w-5 mr-2" />
              Access Employer Portal
              <ArrowRight className="h-5 w-5 ml-2" />
            </Button>
            <Button 
              variant="outline"
              onClick={() => document.getElementById('talent-request')?.scrollIntoView({ behavior: 'smooth' })}
              className="px-8 py-3 text-lg"
              size="lg"
            >
              Request Talent Below
            </Button>
          </div>
        </div>
      </section>

      {/* Portal Benefits */}
      <section className="py-12 bg-blue-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Why Use Our Employer Portal?
            </h2>
            <p className="text-lg text-gray-600">
              Get access to advanced features and manage your hiring process more effectively
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="text-center">
              <CardContent className="p-6">
                <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Crown className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Advanced Dashboard</h3>
                <p className="text-gray-600">
                  Manage multiple job postings, track applications, and analyze hiring metrics in one place.
                </p>
              </CardContent>
            </Card>
            
            <Card className="text-center">
              <CardContent className="p-6">
                <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Zap className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Priority Matching</h3>
                <p className="text-gray-600">
                  Get faster responses and priority access to our best candidates with premium features.
                </p>
              </CardContent>
            </Card>
            
            <Card className="text-center">
              <CardContent className="p-6">
                <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="h-8 w-8 text-purple-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Enhanced Security</h3>
                <p className="text-gray-600">
                  Secure company profiles, private job postings, and protected candidate information.
                </p>
              </CardContent>
            </Card>
          </div>
          
          <div className="text-center mt-8">
            <Button 
              onClick={handleAccessPortal}
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3"
              size="lg"
            >
              Get Started with Portal
              <ArrowRight className="h-5 w-5 ml-2" />
            </Button>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            <div className="text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Fresh Global Talent Pool</h3>
              <p className="text-gray-600">
                Access candidates from around the world, not just your local market.
              </p>
            </div>
            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Zap className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Speed & Precision Matching</h3>
              <p className="text-gray-600">
                Get shortlisted candidates quickly with our advanced matching system.
              </p>
            </div>
            <div className="text-center">
              <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <DollarSign className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Flexible Fee Structures</h3>
              <p className="text-gray-600">
                Choose between success-based fees or retainer models.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Talent Request Form */}
      <section id="talent-request" className="py-12">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-2xl text-center text-gray-900">
                Request Talent
              </CardTitle>
              <p className="text-center text-gray-600">
                Fill out this form for a quick talent request, or use our portal for advanced features
              </p>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="companyName">Company Name *</Label>
                    <Input
                      id="companyName"
                      type="text"
                      value={formData.companyName}
                      onChange={(e) => handleInputChange('companyName', e.target.value)}
                      placeholder="Your company name"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="contactPerson">Contact Person *</Label>
                    <Input
                      id="contactPerson"
                      type="text"
                      value={formData.contactPerson}
                      onChange={(e) => handleInputChange('contactPerson', e.target.value)}
                      placeholder="Your full name"
                      required
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="email">Email Address *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                    placeholder="your.email@company.com"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="jobTitle">Job Title *</Label>
                  <Input
                    id="jobTitle"
                    type="text"
                    value={formData.jobTitle}
                    onChange={(e) => handleInputChange('jobTitle', e.target.value)}
                    placeholder="e.g. Senior Software Engineer"
                    required
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="currency">Currency & Country *</Label>
                    <Select onValueChange={(value) => handleInputChange('currency', value)} value={formData.currency}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select currency" />
                      </SelectTrigger>
                      <SelectContent>
                        {currencyOptions.map((currency) => (
                          <SelectItem key={currency.code} value={currency.code}>
                            <div className="flex items-center space-x-2">
                              <span>{currency.flag}</span>
                              <span>{currency.symbol} {currency.code}</span>
                              <span className="text-gray-500">- {currency.country}</span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="salaryRange">Salary Range *</Label>
                    <Select onValueChange={(value) => handleInputChange('salaryRange', value)} value={formData.salaryRange}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select salary range" />
                      </SelectTrigger>
                      <SelectContent>
                        {salaryRanges.map((range) => (
                          <SelectItem key={range.value} value={range.value}>
                            {range.label}
                          </SelectItem>
                        ))}
                        <SelectItem value="negotiable">Negotiable</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="urgency">Urgency *</Label>
                  <Select onValueChange={(value) => handleInputChange('urgency', value)} value={formData.urgency}>
                    <SelectTrigger>
                      <SelectValue placeholder="How urgently do you need to hire?" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="asap">ASAP (within 1 week)</SelectItem>
                      <SelectItem value="2weeks">Within 2 weeks</SelectItem>
                      <SelectItem value="1month">Within 1 month</SelectItem>
                      <SelectItem value="2months">Within 2 months</SelectItem>
                      <SelectItem value="flexible">Flexible timeline</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="jobDescription">Job Description & Requirements *</Label>
                  <Textarea
                    id="jobDescription"
                    value={formData.jobDescription}
                    onChange={(e) => handleInputChange('jobDescription', e.target.value)}
                    placeholder="Please provide detailed job description, required skills, experience level, location requirements, and any other important details..."
                    rows={6}
                    required
                  />
                </div>

                <Button 
                  type="submit" 
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3"
                  size="lg"
                >
                  <Send className="h-5 w-5 mr-2" />
                  Request Candidates
                </Button>
              </form>

              <div className="mt-6 text-center text-sm text-gray-500">
                <p className="font-semibold text-gray-700 mb-2">
                  🎯 We'll review your requirements and connect you with 3-5 qualified candidates from our global talent network.
                </p>
                <p className="text-xs">
                  No upfront fees - you only pay when you successfully hire through our platform.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}