import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { 
  Users, 
  Globe, 
  TrendingUp, 
  CheckCircle, 
  Star,
  Building2,
  UserCheck,
  Briefcase,
  Award,
  ArrowRight,
  Quote
} from 'lucide-react';

export default function Index() {
  const stats = [
    { label: 'Global Candidates', value: '50K+', icon: Users },
    { label: 'Partner Companies', value: '2K+', icon: Building2 },
    { label: 'Successful Placements', value: '15K+', icon: UserCheck },
    { label: 'Countries Served', value: '45+', icon: Globe },
  ];

  const testimonials = [
    {
      name: 'Sarah Chen',
      role: 'Software Engineer',
      company: 'TechCorp',
      content: 'Found my dream job in Silicon Valley within 2 weeks. The process was smooth and professional.',
      rating: 5
    },
    {
      name: 'Michael Rodriguez',
      role: 'HR Director',
      company: 'Global Solutions Inc.',
      content: 'Excellent quality candidates. We hired 3 amazing developers through their platform.',
      rating: 5
    },
    {
      name: 'Emma Thompson',
      role: 'Marketing Manager',
      company: 'Creative Agency',
      content: 'Professional service and great support throughout the entire recruitment process.',
      rating: 5
    }
  ];

  const industries = [
    'Technology', 'Finance', 'Healthcare', 'Marketing', 'Engineering', 
    'Consulting', 'Education', 'Manufacturing', 'Retail', 'Startups'
  ];

  const inspirationalQuotes = [
    {
      text: "Don't chase a job — chase the value you bring. When you build yourself with discipline, integrity, and courage, the right opportunities don't need to be hunted… they arrive.",
      theme: "value"
    },
    {
      text: "Show up earlier. Work harder. Be honest. Do it when no one is watching — because the effort you put in eventually returns to you, multiplied.",
      theme: "effort"
    },
    {
      text: "You are not applying for a job — you are offering excellence. Let your character speak louder than your CV.",
      theme: "excellence"
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
            Connect Talent with 
            <span className="text-blue-600"> Global Opportunities</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            We bridge the gap between exceptional talent and world-class companies. 
            Whether you're seeking your next career move or looking to hire top talent, 
            we make global recruitment simple and effective.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/candidates">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3">
                <Users className="h-5 w-5 mr-2" />
                Find Your Dream Job
                <ArrowRight className="h-5 w-5 ml-2" />
              </Button>
            </Link>
            <Link to="/employer-dashboard">
              <Button size="lg" variant="outline" className="px-8 py-3 border-blue-600 text-blue-600 hover:bg-blue-50">
                <Building2 className="h-5 w-5 mr-2" />
                Hire Top Talent
                <ArrowRight className="h-5 w-5 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Inspirational Quotes Section */}
      <section className="py-16 bg-gradient-to-r from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">
              Words of Wisdom
            </h2>
            <p className="text-lg text-gray-600">
              Inspiration for your career journey
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {inspirationalQuotes.map((quote, index) => (
              <Card key={index} className="bg-white/80 backdrop-blur-sm border-l-4 border-l-blue-500 hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-3">
                    <Quote className="h-6 w-6 text-blue-500 mt-1 flex-shrink-0" />
                    <div>
                      <p className="text-gray-700 italic leading-relaxed text-sm md:text-base">
                        "{quote.text}"
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <stat.icon className="h-8 w-8 text-blue-600" />
                </div>
                <div className="text-3xl font-bold text-gray-900 mb-2">{stat.value}</div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Why Choose Global Network Recruitment?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We combine cutting-edge technology with human expertise to deliver 
              exceptional recruitment results for both candidates and employers.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="hover:shadow-lg transition-shadow duration-300">
              <CardContent className="p-8 text-center">
                <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Globe className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Global Reach</h3>
                <p className="text-gray-600">
                  Access opportunities and talent from over 45 countries worldwide. 
                  Break geographical barriers and expand your horizons.
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow duration-300">
              <CardContent className="p-8 text-center">
                <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <TrendingUp className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Fast Results</h3>
                <p className="text-gray-600">
                  Our streamlined process delivers results quickly. Most placements 
                  happen within 2-4 weeks of initial contact.
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow duration-300">
              <CardContent className="p-8 text-center">
                <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Award className="h-8 w-8 text-purple-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Quality Guaranteed</h3>
                <p className="text-gray-600">
                  Every candidate is thoroughly vetted and every employer verified. 
                  We ensure quality matches for long-term success.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Industries Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Industries We Serve</h2>
          <div className="flex flex-wrap justify-center gap-3">
            {industries.map((industry, index) => (
              <Badge key={index} variant="outline" className="px-4 py-2 text-sm">
                {industry}
              </Badge>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Success Stories
            </h2>
            <p className="text-xl text-gray-600">
              Hear from our satisfied candidates and employers
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow duration-300">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-gray-700 mb-4 italic">"{testimonial.content}"</p>
                  <div className="border-t pt-4">
                    <p className="font-semibold text-gray-900">{testimonial.name}</p>
                    <p className="text-sm text-gray-600">{testimonial.role}</p>
                    <p className="text-sm text-blue-600">{testimonial.company}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-blue-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Get Started?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Join thousands of successful professionals and companies who trust us 
            with their recruitment needs.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/candidates">
              <Button size="lg" variant="secondary" className="px-8 py-3">
                <Users className="h-5 w-5 mr-2" />
                Upload Your CV
              </Button>
            </Link>
            <Link to="/employer-dashboard">
              <Button size="lg" className="px-8 py-3 bg-white text-blue-600 hover:bg-gray-100">
                <Briefcase className="h-5 w-5 mr-2" />
                Post a Job
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}