import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { 
  Check, 
  Crown, 
  Zap, 
  Users, 
  Building2,
  CreditCard,
  ArrowRight,
  Star,
  Shield,
  Headphones
} from 'lucide-react';

const plans = [
  {
    id: 'free',
    name: 'Free Trial',
    price: 0,
    period: '7 days',
    description: 'Perfect for testing our platform',
    features: [
      '1 job posting',
      '5 candidate profiles',
      'Basic matching',
      'Email support',
      'Standard verification'
    ],
    limitations: [
      'Limited to 1 active job',
      'No priority support',
      'Basic analytics only'
    ],
    popular: false,
    icon: Zap,
    color: 'text-gray-600',
    bgColor: 'bg-gray-50',
    borderColor: 'border-gray-200'
  },
  {
    id: 'basic',
    name: 'Basic Plan',
    price: 299,
    period: 'month',
    description: 'Great for small companies',
    features: [
      '5 job postings',
      '50 candidate profiles',
      'Advanced matching algorithm',
      'Priority email support',
      'Enhanced verification',
      'Basic analytics dashboard',
      'Mobile app access'
    ],
    limitations: [
      'No dedicated account manager',
      'Standard response time'
    ],
    popular: false,
    icon: Building2,
    color: 'text-blue-600',
    bgColor: 'bg-blue-50',
    borderColor: 'border-blue-200'
  },
  {
    id: 'premium',
    name: 'Premium Plan',
    price: 599,
    period: 'month',
    description: 'Most popular for growing teams',
    features: [
      '20 job postings',
      '200 candidate profiles',
      'AI-powered matching',
      'Priority phone & email support',
      'Premium verification',
      'Advanced analytics & reporting',
      'Custom branding',
      'API access',
      'Team collaboration tools'
    ],
    limitations: [],
    popular: true,
    icon: Crown,
    color: 'text-purple-600',
    bgColor: 'bg-purple-50',
    borderColor: 'border-purple-200'
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    price: 1299,
    period: 'month',
    description: 'For large organizations',
    features: [
      'Unlimited job postings',
      'Unlimited candidate access',
      'Custom AI matching models',
      'Dedicated account manager',
      'Premium verification & screening',
      'Custom analytics & reporting',
      'White-label solution',
      'Full API access',
      'Advanced team management',
      'SLA guarantee',
      '24/7 phone support'
    ],
    limitations: [],
    popular: false,
    icon: Star,
    color: 'text-gold-600',
    bgColor: 'bg-yellow-50',
    borderColor: 'border-yellow-200'
  }
];

export default function EmployerSubscription() {
  const [selectedPlan, setSelectedPlan] = useState('premium');
  const [isProcessing, setIsProcessing] = useState(false);
  const { user, updateUser } = useAuth();
  const navigate = useNavigate();

  const handleSelectPlan = async (planId: string) => {
    setIsProcessing(true);
    
    try {
      // Simulate payment processing
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Update user subscription
      updateUser({
        subscriptionPlan: planId as 'free' | 'basic' | 'premium' | 'enterprise',
        subscriptionStatus: 'active'
      });

      toast.success(`Successfully subscribed to ${plans.find(p => p.id === planId)?.name}!`);
      navigate('/employer-dashboard');
    } catch (error) {
      toast.error('Payment failed. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSkipTrial = () => {
    updateUser({
      subscriptionPlan: 'free',
      subscriptionStatus: 'trial'
    });
    navigate('/employer-dashboard');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Building2 className="h-8 w-8 text-blue-600" />
              <span className="text-xl font-bold text-gray-900">Global Network Recruitment</span>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">Welcome, {user?.companyName}</span>
              <Button variant="ghost" onClick={() => navigate('/employer-auth')}>
                Sign Out
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header Section */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Choose Your Plan
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
            Select the perfect plan for your hiring needs. All plans include our core features 
            with varying limits and premium add-ons.
          </p>
          
          <div className="flex items-center justify-center space-x-8 text-sm text-gray-600">
            <div className="flex items-center space-x-2">
              <Shield className="h-4 w-4 text-green-600" />
              <span>30-day money-back guarantee</span>
            </div>
            <div className="flex items-center space-x-2">
              <Headphones className="h-4 w-4 text-blue-600" />
              <span>24/7 customer support</span>
            </div>
            <div className="flex items-center space-x-2">
              <Users className="h-4 w-4 text-purple-600" />
              <span>No setup fees</span>
            </div>
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {plans.map((plan) => {
            const IconComponent = plan.icon;
            const isSelected = selectedPlan === plan.id;
            
            return (
              <Card 
                key={plan.id} 
                className={`relative transition-all duration-200 hover:shadow-lg cursor-pointer ${
                  plan.popular ? 'ring-2 ring-purple-500 scale-105' : ''
                } ${isSelected ? 'ring-2 ring-blue-500' : ''} ${plan.borderColor}`}
                onClick={() => setSelectedPlan(plan.id)}
              >
                {plan.popular && (
                  <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-purple-600 text-white">
                    Most Popular
                  </Badge>
                )}
                
                <CardHeader className="text-center pb-4">
                  <div className={`w-12 h-12 mx-auto mb-4 rounded-full ${plan.bgColor} flex items-center justify-center`}>
                    <IconComponent className={`h-6 w-6 ${plan.color}`} />
                  </div>
                  <CardTitle className="text-xl font-bold">{plan.name}</CardTitle>
                  <div className="mt-2">
                    <span className="text-3xl font-bold text-gray-900">
                      ${plan.price}
                    </span>
                    <span className="text-gray-600">/{plan.period}</span>
                  </div>
                  <p className="text-sm text-gray-600 mt-2">{plan.description}</p>
                </CardHeader>
                
                <CardContent className="pt-0">
                  <ul className="space-y-3 mb-6">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-start space-x-2">
                        <Check className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                        <span className="text-sm text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <Button 
                    className={`w-full ${
                      plan.popular 
                        ? 'bg-purple-600 hover:bg-purple-700' 
                        : 'bg-blue-600 hover:bg-blue-700'
                    }`}
                    onClick={(e) => {
                      e.stopPropagation();
                      handleSelectPlan(plan.id);
                    }}
                    disabled={isProcessing}
                  >
                    {isProcessing && selectedPlan === plan.id ? (
                      'Processing...'
                    ) : plan.id === 'free' ? (
                      'Start Free Trial'
                    ) : (
                      'Select Plan'
                    )}
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Payment Security */}
        <div className="text-center">
          <div className="inline-flex items-center space-x-4 text-sm text-gray-600 bg-white rounded-lg px-6 py-3 shadow-sm">
            <CreditCard className="h-4 w-4" />
            <span>Secure payment powered by Stripe</span>
            <span>•</span>
            <span>SSL encrypted</span>
            <span>•</span>
            <span>Cancel anytime</span>
          </div>
        </div>

        {/* Skip Option */}
        <div className="text-center mt-8">
          <Button 
            variant="ghost" 
            onClick={handleSkipTrial}
            className="text-gray-600 hover:text-gray-900"
          >
            Skip for now and start with free trial
          </Button>
        </div>
      </div>
    </div>
  );
}