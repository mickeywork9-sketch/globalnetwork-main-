import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import { 
  Crown,
  Check,
  X,
  Target,
  Zap,
  Award,
  Eye,
  Bell,
  TrendingUp,
  Shield,
  CreditCard,
  ArrowLeft,
  Star
} from 'lucide-react';

export default function JobSeekerUpgrade() {
  const navigate = useNavigate();
  const [paymentMethod, setPaymentMethod] = useState('card');
  const [cardDetails, setCardDetails] = useState({
    number: '',
    expiry: '',
    cvv: '',
    name: ''
  });

  const handleUpgrade = () => {
    // Simulate payment processing
    toast.success('Payment successful! Welcome to Pro+');
    setTimeout(() => {
      navigate('/job-seeker-dashboard');
    }, 2000);
  };

  const features = {
    free: [
      { name: 'Basic job search', included: true },
      { name: 'Apply to jobs manually', included: true },
      { name: 'Standard profile visibility', included: true },
      { name: 'Basic application tracking', included: true },
      { name: 'Direct job offers', included: false },
      { name: 'AI-powered matching', included: false },
      { name: 'Priority application processing', included: false },
      { name: 'Premium profile visibility', included: false },
      { name: 'Advanced analytics', included: false },
      { name: 'Dedicated support', included: false }
    ],
    pro: [
      { name: 'Everything in Free', included: true },
      { name: 'Direct job offers to your dashboard', included: true },
      { name: 'AI-powered job matching (95% accuracy)', included: true },
      { name: 'Priority application processing', included: true },
      { name: 'Premium profile visibility to top employers', included: true },
      { name: 'Advanced profile analytics', included: true },
      { name: 'Instant job alerts', included: true },
      { name: 'Salary insights and negotiation tips', included: true },
      { name: 'Dedicated career consultant', included: true },
      { name: '24/7 priority support', included: true }
    ]
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" onClick={() => navigate(-1)}>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Upgrade to Pro+</h1>
                <p className="text-sm text-gray-600">Unlock premium job seeker features</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Plan Comparison */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Crown className="h-6 w-6 text-purple-600 mr-2" />
                  Why Upgrade to Pro+?
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-4 flex items-center">
                      <Badge variant="outline" className="mr-2">FREE</Badge>
                      Current Plan
                    </h3>
                    <ul className="space-y-3">
                      {features.free.map((feature, index) => (
                        <li key={index} className="flex items-center text-sm">
                          {feature.included ? (
                            <Check className="h-4 w-4 text-green-500 mr-2 flex-shrink-0" />
                          ) : (
                            <X className="h-4 w-4 text-red-500 mr-2 flex-shrink-0" />
                          )}
                          <span className={feature.included ? 'text-gray-700' : 'text-gray-400'}>
                            {feature.name}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-semibold text-gray-900 mb-4 flex items-center">
                      <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white mr-2">
                        <Crown className="h-3 w-3 mr-1" />
                        PRO+
                      </Badge>
                      Recommended
                    </h3>
                    <ul className="space-y-3">
                      {features.pro.map((feature, index) => (
                        <li key={index} className="flex items-center text-sm">
                          <Check className="h-4 w-4 text-green-500 mr-2 flex-shrink-0" />
                          <span className="text-gray-700">{feature.name}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Success Stories */}
            <Card>
              <CardHeader>
                <CardTitle>Pro+ Success Stories</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="border-l-4 border-l-purple-500 pl-4">
                    <div className="flex items-center mb-2">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                      ))}
                    </div>
                    <p className="text-sm text-gray-700 italic">
                      "Received 3 direct job offers within the first week of upgrading. 
                      The AI matching is incredibly accurate!"
                    </p>
                    <p className="text-xs text-gray-500 mt-2">- Sarah M., Software Engineer</p>
                  </div>
                  
                  <div className="border-l-4 border-l-purple-500 pl-4">
                    <div className="flex items-center mb-2">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                      ))}
                    </div>
                    <p className="text-sm text-gray-700 italic">
                      "The career consultant helped me negotiate a 30% salary increase. 
                      Best investment I've made in my career!"
                    </p>
                    <p className="text-xs text-gray-500 mt-2">- Michael R., Product Manager</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Key Benefits */}
            <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200">
              <CardContent className="p-6">
                <h3 className="font-semibold text-gray-900 mb-4">Key Pro+ Benefits</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-start space-x-3">
                    <Target className="h-5 w-5 text-purple-600 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-gray-900">Direct Job Offers</h4>
                      <p className="text-sm text-gray-600">Top employers reach out to you directly</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <Zap className="h-5 w-5 text-purple-600 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-gray-900">AI-Powered Matching</h4>
                      <p className="text-sm text-gray-600">95% accuracy in job recommendations</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <Award className="h-5 w-5 text-purple-600 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-gray-900">Premium Visibility</h4>
                      <p className="text-sm text-gray-600">Stand out to top-tier companies</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <TrendingUp className="h-5 w-5 text-purple-600 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-gray-900">Career Growth</h4>
                      <p className="text-sm text-gray-600">Dedicated consultant & insights</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Payment Section */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Pro+ Plan</span>
                  <Badge className="bg-green-100 text-green-800">Limited Time</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center mb-6">
                  <div className="flex items-baseline justify-center">
                    <span className="text-4xl font-bold text-gray-900">$6.49</span>
                    <span className="text-lg text-gray-600 ml-2">USD</span>
                  </div>
                  <p className="text-sm text-gray-600 mt-2">One-time payment • Valid for 3 months</p>
                  <div className="bg-green-50 border border-green-200 rounded-lg p-3 mt-4">
                    <p className="text-sm text-green-800">
                      <Shield className="h-4 w-4 inline mr-1" />
                      30-day money-back guarantee
                    </p>
                  </div>
                </div>

                <Separator className="my-6" />

                <div className="space-y-6">
                  <div>
                    <Label className="text-base font-medium">Payment Method</Label>
                    <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod} className="mt-3">
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="card" id="card" />
                        <Label htmlFor="card" className="flex items-center cursor-pointer">
                          <CreditCard className="h-4 w-4 mr-2" />
                          Credit/Debit Card
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>

                  {paymentMethod === 'card' && (
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="cardName">Cardholder Name</Label>
                        <Input
                          id="cardName"
                          value={cardDetails.name}
                          onChange={(e) => setCardDetails(prev => ({ ...prev, name: e.target.value }))}
                          placeholder="John Doe"
                        />
                      </div>
                      <div>
                        <Label htmlFor="cardNumber">Card Number</Label>
                        <Input
                          id="cardNumber"
                          value={cardDetails.number}
                          onChange={(e) => setCardDetails(prev => ({ ...prev, number: e.target.value }))}
                          placeholder="1234 5678 9012 3456"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="expiry">Expiry Date</Label>
                          <Input
                            id="expiry"
                            value={cardDetails.expiry}
                            onChange={(e) => setCardDetails(prev => ({ ...prev, expiry: e.target.value }))}
                            placeholder="MM/YY"
                          />
                        </div>
                        <div>
                          <Label htmlFor="cvv">CVV</Label>
                          <Input
                            id="cvv"
                            value={cardDetails.cvv}
                            onChange={(e) => setCardDetails(prev => ({ ...prev, cvv: e.target.value }))}
                            placeholder="123"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  <Button 
                    onClick={handleUpgrade} 
                    className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white py-3"
                    size="lg"
                  >
                    <Crown className="h-5 w-5 mr-2" />
                    Upgrade to Pro+ - $6.49 USD
                  </Button>

                  <div className="text-xs text-gray-500 text-center space-y-1">
                    <p>By upgrading, you agree to our Terms of Service and Privacy Policy.</p>
                    <p>Your subscription will be valid for 3 months from the date of purchase.</p>
                    <p>
                      <Shield className="h-3 w-3 inline mr-1" />
                      Secure payment processed by Stripe
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* FAQ */}
            <Card>
              <CardHeader>
                <CardTitle>Frequently Asked Questions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium text-gray-900">How quickly will I see results?</h4>
                    <p className="text-sm text-gray-600 mt-1">
                      Most Pro+ users receive their first direct job offer within 7-14 days.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900">Can I cancel anytime?</h4>
                    <p className="text-sm text-gray-600 mt-1">
                      Yes, with our 30-day money-back guarantee. No questions asked.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900">What happens after 3 months?</h4>
                    <p className="text-sm text-gray-600 mt-1">
                      You can choose to renew or continue with our free plan.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}