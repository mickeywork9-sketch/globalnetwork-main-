import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import { 
  User, 
  Upload, 
  Search, 
  Star,
  Crown,
  Briefcase,
  MapPin,
  DollarSign,
  Calendar,
  Eye,
  Heart,
  Send,
  CheckCircle,
  Zap,
  Target,
  TrendingUp,
  Bell,
  Settings,
  LogOut,
  FileText,
  Award
} from 'lucide-react';

interface JobOffer {
  id: string;
  title: string;
  company: string;
  location: string;
  salary: string;
  type: string;
  matchScore: number;
  postedDate: string;
  description: string;
  requirements: string[];
  benefits: string[];
  isDirectOffer: boolean;
}

interface Application {
  id: string;
  jobTitle: string;
  company: string;
  appliedDate: string;
  status: 'pending' | 'reviewing' | 'interviewed' | 'offered' | 'rejected';
}

export default function JobSeekerDashboard() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [userPlan, setUserPlan] = useState<'free' | 'pro'>('free');
  const [showUpgrade, setShowUpgrade] = useState(false);

  // Profile state
  const [profile, setProfile] = useState({
    name: 'John Doe',
    email: 'john.doe@email.com',
    phone: '+1 (555) 123-4567',
    location: 'San Francisco, CA',
    title: 'Software Engineer',
    experience: '5+ years',
    skills: 'React, Node.js, TypeScript, Python',
    summary: 'Experienced software engineer with expertise in full-stack development...',
    resume: null as File | null,
    profileCompletion: 85
  });

  // Sample job offers (Pro+ feature)
  const [jobOffers] = useState<JobOffer[]>([
    {
      id: '1',
      title: 'Senior Full Stack Developer',
      company: 'TechCorp Solutions',
      location: 'San Francisco, CA',
      salary: '$120,000 - $160,000',
      type: 'Full-time',
      matchScore: 95,
      postedDate: '2024-01-15',
      description: 'We are looking for a senior full stack developer to join our innovative team...',
      requirements: ['React', 'Node.js', 'TypeScript', '5+ years experience'],
      benefits: ['Health insurance', 'Stock options', 'Remote work', 'Learning budget'],
      isDirectOffer: true
    },
    {
      id: '2',
      title: 'Lead Software Engineer',
      company: 'Innovation Labs',
      location: 'Remote',
      salary: '$140,000 - $180,000',
      type: 'Full-time',
      matchScore: 88,
      postedDate: '2024-01-12',
      description: 'Lead a team of developers in building next-generation applications...',
      requirements: ['Leadership experience', 'React', 'Python', 'Cloud platforms'],
      benefits: ['Equity package', 'Flexible hours', 'Health benefits', 'Conference budget'],
      isDirectOffer: true
    }
  ]);

  // Sample applications
  const [applications] = useState<Application[]>([
    {
      id: '1',
      jobTitle: 'Frontend Developer',
      company: 'StartupXYZ',
      appliedDate: '2024-01-10',
      status: 'reviewing'
    },
    {
      id: '2',
      jobTitle: 'React Developer',
      company: 'WebTech Inc',
      appliedDate: '2024-01-08',
      status: 'interviewed'
    },
    {
      id: '3',
      jobTitle: 'Software Engineer',
      company: 'DevCorp',
      appliedDate: '2024-01-05',
      status: 'pending'
    }
  ]);

  const handleUpgrade = () => {
    navigate('/job-seeker-upgrade');
  };

  const handleResumeUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setProfile(prev => ({ ...prev, resume: file }));
      toast.success('Resume uploaded successfully!');
    }
  };

  const handleProfileUpdate = () => {
    toast.success('Profile updated successfully!');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'reviewing': return 'bg-blue-100 text-blue-800';
      case 'interviewed': return 'bg-purple-100 text-purple-800';
      case 'offered': return 'bg-green-100 text-green-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPlanBadge = () => {
    return userPlan === 'pro' ? (
      <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white">
        <Crown className="h-3 w-3 mr-1" />
        PRO+ PLAN
      </Badge>
    ) : (
      <Badge variant="outline">FREE PLAN</Badge>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <User className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-xl font-bold text-gray-900">Job Seeker Dashboard</h1>
                <p className="text-sm text-gray-600">{profile.name}</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              {getPlanBadge()}
              {userPlan === 'free' && (
                <Button variant="outline" size="sm" onClick={handleUpgrade}>
                  <Crown className="h-4 w-4 mr-2" />
                  Upgrade to Pro+
                </Button>
              )}
              <Button variant="ghost" size="sm">
                <Bell className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <Settings className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-5 mb-8">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="job-offers">
              Job Offers
              {userPlan === 'pro' && jobOffers.length > 0 && (
                <Badge className="ml-2 bg-red-500 text-white text-xs px-1 py-0">
                  {jobOffers.length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="applications">Applications</TabsTrigger>
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="search">Job Search</TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-6">
            {/* Profile Completion */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  Profile Completion
                  <span className="text-sm font-normal text-gray-600">
                    {profile.profileCompletion}% Complete
                  </span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Progress value={profile.profileCompletion} className="mb-4" />
                <div className="flex space-x-2">
                  <Button size="sm" variant="outline" onClick={() => setActiveTab('profile')}>
                    Complete Profile
                  </Button>
                  {!profile.resume && (
                    <Button size="sm" variant="outline">
                      <Upload className="h-4 w-4 mr-2" />
                      Upload Resume
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Applications</p>
                      <p className="text-2xl font-bold text-gray-900">{applications.length}</p>
                    </div>
                    <Send className="h-8 w-8 text-blue-600" />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Profile Views</p>
                      <p className="text-2xl font-bold text-gray-900">
                        {userPlan === 'pro' ? '47' : '12'}
                      </p>
                    </div>
                    <Eye className="h-8 w-8 text-green-600" />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">
                        {userPlan === 'pro' ? 'Direct Offers' : 'Saved Jobs'}
                      </p>
                      <p className="text-2xl font-bold text-gray-900">
                        {userPlan === 'pro' ? jobOffers.length : '5'}
                      </p>
                    </div>
                    {userPlan === 'pro' ? (
                      <Target className="h-8 w-8 text-purple-600" />
                    ) : (
                      <Heart className="h-8 w-8 text-red-600" />
                    )}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Match Score</p>
                      <p className="text-2xl font-bold text-gray-900">
                        {userPlan === 'pro' ? '92%' : '78%'}
                      </p>
                    </div>
                    <TrendingUp className="h-8 w-8 text-orange-600" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Recent Activity */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Applications</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {applications.slice(0, 3).map((app) => (
                      <div key={app.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                          <h4 className="font-medium text-gray-900">{app.jobTitle}</h4>
                          <p className="text-sm text-gray-600">{app.company} • {app.appliedDate}</p>
                        </div>
                        <Badge className={getStatusColor(app.status)}>
                          {app.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Button className="w-full justify-start" variant="outline" onClick={() => setActiveTab('search')}>
                      <Search className="h-4 w-4 mr-2" />
                      Search Jobs
                    </Button>
                    <Button className="w-full justify-start" variant="outline" onClick={() => setActiveTab('profile')}>
                      <User className="h-4 w-4 mr-2" />
                      Update Profile
                    </Button>
                    {userPlan === 'pro' ? (
                      <Button className="w-full justify-start" variant="outline" onClick={() => setActiveTab('job-offers')}>
                        <Target className="h-4 w-4 mr-2" />
                        View Direct Offers
                      </Button>
                    ) : (
                      <Button className="w-full justify-start" variant="outline" onClick={handleUpgrade}>
                        <Crown className="h-4 w-4 mr-2" />
                        Upgrade to Pro+
                      </Button>
                    )}
                    <Button className="w-full justify-start" variant="outline" onClick={() => setActiveTab('applications')}>
                      <FileText className="h-4 w-4 mr-2" />
                      Track Applications
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Job Offers Tab */}
          <TabsContent value="job-offers" className="space-y-6">
            {userPlan === 'free' ? (
              <Card className="border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-pink-50">
                <CardContent className="p-8 text-center">
                  <Crown className="h-16 w-16 text-purple-600 mx-auto mb-4" />
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">Unlock Direct Job Offers</h3>
                  <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
                    Upgrade to Pro+ and receive personalized job offers delivered directly to your dashboard. 
                    Top employers will find you based on your skills and experience.
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                    <div className="flex items-center justify-center space-x-2">
                      <Target className="h-5 w-5 text-purple-600" />
                      <span className="text-sm">AI-Powered Matching</span>
                    </div>
                    <div className="flex items-center justify-center space-x-2">
                      <Zap className="h-5 w-5 text-purple-600" />
                      <span className="text-sm">Priority Processing</span>
                    </div>
                    <div className="flex items-center justify-center space-x-2">
                      <Award className="h-5 w-5 text-purple-600" />
                      <span className="text-sm">Premium Visibility</span>
                    </div>
                  </div>
                  <Button size="lg" onClick={handleUpgrade} className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
                    <Crown className="h-5 w-5 mr-2" />
                    Upgrade to Pro+ - $49 (3 months)
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <div>
                    <h2 className="text-xl font-semibold text-gray-900">Direct Job Offers</h2>
                    <p className="text-gray-600">Personalized opportunities delivered to you</p>
                  </div>
                  <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white">
                    {jobOffers.length} New Offers
                  </Badge>
                </div>

                <div className="grid gap-6">
                  {jobOffers.map((offer) => (
                    <Card key={offer.id} className="border-l-4 border-l-purple-500 hover:shadow-lg transition-shadow">
                      <CardContent className="p-6">
                        <div className="flex justify-between items-start mb-4">
                          <div className="flex-1">
                            <div className="flex items-center space-x-3 mb-2">
                              <h3 className="text-xl font-semibold text-gray-900">{offer.title}</h3>
                              <Badge className="bg-purple-100 text-purple-800">
                                <Target className="h-3 w-3 mr-1" />
                                {offer.matchScore}% Match
                              </Badge>
                              {offer.isDirectOffer && (
                                <Badge className="bg-green-100 text-green-800">
                                  Direct Offer
                                </Badge>
                              )}
                            </div>
                            <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
                              <span className="flex items-center">
                                <Briefcase className="h-4 w-4 mr-1" />
                                {offer.company}
                              </span>
                              <span className="flex items-center">
                                <MapPin className="h-4 w-4 mr-1" />
                                {offer.location}
                              </span>
                              <span className="flex items-center">
                                <DollarSign className="h-4 w-4 mr-1" />
                                {offer.salary}
                              </span>
                              <span className="flex items-center">
                                <Calendar className="h-4 w-4 mr-1" />
                                {offer.postedDate}
                              </span>
                            </div>
                            <p className="text-gray-700 mb-4">{offer.description}</p>
                            <div className="flex flex-wrap gap-2 mb-4">
                              {offer.requirements.map((req, index) => (
                                <Badge key={index} variant="outline" className="text-xs">
                                  {req}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex justify-between items-center pt-4 border-t">
                          <div className="flex space-x-2">
                            <Button size="sm" className="bg-purple-600 hover:bg-purple-700">
                              <Send className="h-4 w-4 mr-1" />
                              Apply Now
                            </Button>
                            <Button size="sm" variant="outline">
                              <Eye className="h-4 w-4 mr-1" />
                              View Details
                            </Button>
                            <Button size="sm" variant="outline">
                              <Heart className="h-4 w-4 mr-1" />
                              Save
                            </Button>
                          </div>
                          <div className="text-sm text-gray-500">
                            Expires in 14 days
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}
          </TabsContent>

          {/* Applications Tab */}
          <TabsContent value="applications" className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-xl font-semibold text-gray-900">My Applications</h2>
                <p className="text-gray-600">Track your job application status</p>
              </div>
            </div>

            <div className="grid gap-4">
              {applications.map((app) => (
                <Card key={app.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-center">
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900">{app.jobTitle}</h3>
                        <p className="text-gray-600">{app.company}</p>
                        <p className="text-sm text-gray-500">Applied on {app.appliedDate}</p>
                      </div>
                      <div className="text-right">
                        <Badge className={getStatusColor(app.status)}>
                          {app.status}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Profile Tab */}
          <TabsContent value="profile" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Personal Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="name">Full Name</Label>
                    <Input
                      id="name"
                      value={profile.name}
                      onChange={(e) => setProfile(prev => ({ ...prev, name: e.target.value }))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={profile.email}
                      onChange={(e) => setProfile(prev => ({ ...prev, email: e.target.value }))}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="phone">Phone</Label>
                    <Input
                      id="phone"
                      value={profile.phone}
                      onChange={(e) => setProfile(prev => ({ ...prev, phone: e.target.value }))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="location">Location</Label>
                    <Input
                      id="location"
                      value={profile.location}
                      onChange={(e) => setProfile(prev => ({ ...prev, location: e.target.value }))}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="title">Job Title</Label>
                    <Input
                      id="title"
                      value={profile.title}
                      onChange={(e) => setProfile(prev => ({ ...prev, title: e.target.value }))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="experience">Experience Level</Label>
                    <Select onValueChange={(value) => setProfile(prev => ({ ...prev, experience: value }))}>
                      <SelectTrigger>
                        <SelectValue placeholder={profile.experience} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="entry">Entry Level (0-2 years)</SelectItem>
                        <SelectItem value="mid">Mid Level (3-5 years)</SelectItem>
                        <SelectItem value="senior">Senior Level (5+ years)</SelectItem>
                        <SelectItem value="lead">Lead/Principal (8+ years)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="skills">Skills</Label>
                  <Input
                    id="skills"
                    value={profile.skills}
                    onChange={(e) => setProfile(prev => ({ ...prev, skills: e.target.value }))}
                    placeholder="React, Node.js, TypeScript, Python..."
                  />
                </div>

                <div>
                  <Label htmlFor="summary">Professional Summary</Label>
                  <Textarea
                    id="summary"
                    value={profile.summary}
                    onChange={(e) => setProfile(prev => ({ ...prev, summary: e.target.value }))}
                    rows={4}
                  />
                </div>

                <div>
                  <Label htmlFor="resume">Resume</Label>
                  <Input
                    id="resume"
                    type="file"
                    accept=".pdf,.doc,.docx"
                    onChange={handleResumeUpload}
                    className="file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                  />
                  {profile.resume && (
                    <p className="text-sm text-green-600 mt-2">
                      <CheckCircle className="h-4 w-4 inline mr-1" />
                      Resume uploaded: {profile.resume.name}
                    </p>
                  )}
                </div>

                <Button onClick={handleProfileUpdate} className="bg-blue-600 hover:bg-blue-700">
                  Save Profile
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Job Search Tab */}
          <TabsContent value="search" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Job Search</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <Input placeholder="Job title or keywords" />
                  <Input placeholder="Location" />
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    <Search className="h-4 w-4 mr-2" />
                    Search Jobs
                  </Button>
                </div>
                
                <div className="text-center py-12 text-gray-500">
                  <Search className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                  <p>Enter your search criteria to find relevant job opportunities</p>
                  {userPlan === 'free' && (
                    <p className="text-sm mt-2">
                      Upgrade to Pro+ for AI-powered job recommendations
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}