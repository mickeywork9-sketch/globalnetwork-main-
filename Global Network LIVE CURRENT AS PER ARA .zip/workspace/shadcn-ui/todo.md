# Global Network Recruitment Website - MVP Todo

## Pages to Create:
1. **Homepage (src/pages/Index.tsx)** - Hero section, How It Works, Why Choose Us, Dual CTAs
2. **For Candidates (src/pages/Candidates.tsx)** - CV upload form and benefits
3. **For Employers (src/pages/Employers.tsx)** - Talent request form and benefits
4. **About Us (src/pages/About.tsx)** - Company story and values
5. **Contact (src/pages/Contact.tsx)** - Contact form and details

## Components to Create:
1. **Header (src/components/Header.tsx)** - Navigation with logo and menu
2. **Footer (src/components/Footer.tsx)** - Footer with contact info
3. **HeroSection (src/components/HeroSection.tsx)** - Homepage hero
4. **HowItWorks (src/components/HowItWorks.tsx)** - 3-column process explanation
5. **WhyChooseUs (src/components/WhyChooseUs.tsx)** - Trust-building section
6. **CVUploadForm (src/components/CVUploadForm.tsx)** - Candidate form
7. **TalentRequestForm (src/components/TalentRequestForm.tsx)** - Employer form

## Key Features:
- Blue + white + grey color scheme
- Mobile-first responsive design
- Form validation and submission
- WhatsApp integration
- Professional, clean layout
- Strong CTAs throughout

## Files to Update:
- index.html (title and meta)
- App.tsx (routing)
- All page components
- All UI components