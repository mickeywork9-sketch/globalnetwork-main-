import { Card, CardContent } from '@/components/ui/card';
import { Globe, Zap, Shield, Heart } from 'lucide-react';

export default function About() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      {/* Hero Section */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Your Digital Recruitment Partner
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Connecting ambitious candidates with employers in need of talent through 
            cutting-edge digital solutions and personalized expertise.
          </p>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card className="shadow-lg">
            <CardContent className="p-8 md:p-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-6 text-center">
                Our Story
              </h2>
              <div className="prose prose-lg max-w-none text-gray-600">
                <p className="mb-6">
                  Global Network Recruitment was founded to bridge the gap between talented 
                  professionals seeking new opportunities and companies in need of exceptional talent. 
                  We recognized that traditional recruitment methods were often slow, inefficient, 
                  and limited by geographical boundaries.
                </p>
                <p className="mb-6">
                  Our mission is simple: combine cutting-edge digital sourcing with personalized 
                  recruitment expertise to deliver placements that last. Whether you're a candidate 
                  looking to take your career global or an employer seeking the perfect addition 
                  to your team, we're here to make meaningful connections happen.
                </p>
                <p>
                  We believe that great talent knows no borders, and the right opportunity 
                  can transform both careers and companies. That's why we've built a platform 
                  that makes global recruitment accessible, efficient, and successful for everyone involved.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Our Values
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Heart className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Integrity</h3>
                <p className="text-gray-600">
                  We build trust through transparency, honesty, and ethical practices 
                  in every interaction.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Zap className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Speed</h3>
                <p className="text-gray-600">
                  Time is valuable. We deliver fast results without compromising 
                  on quality or accuracy.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Globe className="h-8 w-8 text-purple-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Global Reach</h3>
                <p className="text-gray-600">
                  We connect talent and opportunities across continents, 
                  breaking down geographical barriers.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="bg-orange-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="h-8 w-8 text-orange-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Confidentiality</h3>
                <p className="text-gray-600">
                  Your privacy and sensitive information are protected with 
                  the highest security standards.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Why Work With Us */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Why Work With Us
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card>
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-3">
                  For Candidates
                </h3>
                <ul className="space-y-2 text-gray-600">
                  <li>• Access to exclusive global opportunities</li>
                  <li>• No fees - completely free for job seekers</li>
                  <li>• Personalized career guidance and support</li>
                  <li>• Confidential job search process</li>
                  <li>• Interview preparation and coaching</li>
                  <li>• Long-term career relationship building</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-3">
                  For Employers
                </h3>
                <ul className="space-y-2 text-gray-600">
                  <li>• Access to pre-screened, qualified candidates</li>
                  <li>• Flexible fee structures to suit your budget</li>
                  <li>• Reduced time-to-hire with faster placements</li>
                  <li>• Global talent pool beyond local markets</li>
                  <li>• Replacement guarantee for peace of mind</li>
                  <li>• Dedicated account management support</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-blue-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-6">
            Ready to Get Started?
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            Join thousands of successful placements worldwide
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="/candidates"
              className="bg-white text-blue-600 px-8 py-3 rounded-md font-semibold hover:bg-gray-100 transition-colors"
            >
              Upload Your CV
            </a>
            <a
              href="/employers"
              className="border-2 border-white text-white px-8 py-3 rounded-md font-semibold hover:bg-white hover:text-blue-600 transition-colors"
            >
              Hire Talent
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}